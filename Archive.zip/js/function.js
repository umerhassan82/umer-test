$(document).ready(function(){
    $(".tabsNav li").click(function(){
        var tabIDSplit = $(this).attr("id").split("-");
        var tabID = tabIDSplit[1];
        $(".tabsNav li").removeClass("active");
        $(this).addClass("active");

        $(".tabs").hide();
        $("#tab-"+tabID).show();

        return false;
    });
});